package com.cg.education_system.Controller;

import java.util.List;

import javax.validation.Valid;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.education_system.Service.StudentService;
import com.cg.education_system.entity.Student;

@RestController
@RequestMapping("/es")
@CrossOrigin("*")
public class StudentController {
	Log LOGGER = LogFactory.getFactory().getLog(StudentController.class);
	@Autowired
	StudentService studentService;
	
	@GetMapping("/students")
	public List<Student> getAllStudents(){
		LOGGER.info("Entry: StudentController - getAllStudents");
		List<Student> student = studentService.getAllStudents();
		LOGGER.info("Exit: StudentController - getAllStudents");
		return student;
		
	}
	@GetMapping("/students/{id}")
	public Student getStudent(@PathVariable("id") long id) {
		LOGGER.info("Entry: StudentController - getStudent");
		Student studentDto = studentService.getStudent(id);
		LOGGER.info("Exit: StudentController - getStudent");
		return studentDto;
	}
	
	@Validated
	@PostMapping("/students")
	public Student saveStudent(@RequestBody @Valid Student student) {
		LOGGER.info("Entry: StudentController - saveStudent");
		Student studentDto = studentService.saveStudent(student);
		System.out.println("Successfully added student "+ student);
		LOGGER.info("Exit: StudentController - saveStudent");
		return studentDto;
		
	}
	@PutMapping("/updateStudent/{id}")
	public Student updateStudent(@RequestBody Student student) {
		LOGGER.info("Entry: StudentController - updateStudent");
		Student studentDto = studentService.updateStudent(student);
		LOGGER.info("Exit: StudentController - updateStudent");
		return studentDto;
	}
		

}
