package com.cg.education_system.entity;

import java.io.Serializable;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.Data;
import lombok.NoArgsConstructor;


@Entity
//@AllArgsConstructor
@NoArgsConstructor
@Data
@Table(name ="trainer")
public class Trainer {
	
	
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "trainer_id")
	private long id;
	
	@NotBlank(message = "first name must not be null or empty")
	@Column(name = "first_name")
	private String firstName;
	
	@NotBlank(message = "last name must not be null or empty")
	@Column(name = "last_name")
	private String lastName;
	
//	@NotBlank(message = "mobile number must not be null or empty")
	@Column(name = "mobile")
	private long mobile;
	
	@NotBlank(message = "Email must not be null or empty")
	@Email(message = "email must be in web-format abc@xyz.com")
	@Column(name = "email")
	private String email;
	
	
//	@OneToOne
//	@JoinColumn(name = "course_id",insertable=false,updatable=false)
//	private Course course;
//	
//	@Column(name = "course_id")
//	private long courseId;
	

}
