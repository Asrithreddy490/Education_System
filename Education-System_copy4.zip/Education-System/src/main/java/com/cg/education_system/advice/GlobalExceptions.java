package com.cg.education_system.advice;

import java.util.LinkedHashMap;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.cg.education_system.Exception.PaymentNotFoundException;
import com.cg.education_system.Exception.StudentNotFoundExcption;
import com.cg.education_system.Exception.TrainerNotFoundException;

@RestControllerAdvice
public class GlobalExceptions {
	
	@ResponseStatus(HttpStatus.BAD_REQUEST)
	@ExceptionHandler(MethodArgumentNotValidException.class)
	public Map<String, String> handleBadRequest(MethodArgumentNotValidException ex){
		Map<String, String> erros = new LinkedHashMap<>();
		ex.getBindingResult().getFieldErrors().forEach(error -> {
			erros.put(error.getField(), error.getDefaultMessage());
		});
		
		return erros;		
	}
	
	@ResponseStatus(HttpStatus.NOT_FOUND)
	@ExceptionHandler(StudentNotFoundExcption.class)
	public String notFoundHandlaer(StudentNotFoundExcption ex){
		return ex.getMessage();
	}
	
	@ResponseStatus(HttpStatus.NOT_FOUND)
	@ExceptionHandler(TrainerNotFoundException.class)
	public String notFoundHandlaer(TrainerNotFoundException ex){
		return ex.getMessage();
	}
	

	@ResponseStatus(HttpStatus.NOT_FOUND)
	@ExceptionHandler(PaymentNotFoundException.class)
	public String notFoundHandlaer(PaymentNotFoundException ex){
		return ex.getMessage();
	}
	
	
	@ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
	@ExceptionHandler(Exception.class)
	public String internalServerError(Exception ex){
		return ex.getMessage();
	}

}
