package com.cg.education_system.entity;

import java.io.Serializable;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotBlank;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "course")
@Data
//@AllArgsConstructor
@NoArgsConstructor
public class Course {


	

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "course_id")
	private long id;
	
	@NotBlank(message = "course must not be null or empty")
	@Column(name = "course_name")
	private String courseName;
	
	@Column(name = "course_amount")
	private Long courseAmount;

	@JsonIgnore
	@OneToMany
	@JoinColumn(name="course_id")
    private List<Payment> payments;
	
//	@OneToOne(mappedBy="course")
//	private Trainer trainer;
//	
	
		
}