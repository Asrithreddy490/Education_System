package com.cg.education_system.Controller;

import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.education_system.Service.CourseService;
import com.cg.education_system.entity.Course;
import com.cg.education_system.entity.Payment;

@RestController
@RequestMapping("/es")
@CrossOrigin("*")
public class CourseController {
	Log LOGGER = LogFactory.getFactory().getLog(CourseController.class);
	@Autowired
	CourseService courseService;
	
	@GetMapping("/courses")
	public List<Course> getAllCourses(){
		LOGGER.info("PaymentController::getAllPayments::Entered");
		List<Course> course = courseService.getAllCourses();
		LOGGER.info("PaymentController::getAllPayments::Exits");
		return course;
		
	}
	
	@GetMapping("/courses/{id}")
	public Course getCourse(@PathVariable("id") long id) {
		LOGGER.info("Entry: CourseController - getCourse");
		Course courseDto = courseService.getCourse(id);
		LOGGER.info("Exit: CourseController - getCourse");
		return courseDto;
	}
	
	
	@PostMapping("/courses")
	public Course saveCourse(@RequestBody Course course) {
		LOGGER.info("Entry: CourseController - saveCourse");
		Course courseDto = courseService.saveCourse(course);
		LOGGER.info("Exit: CourseController - saveCourse");
		return courseDto;
		
	}
	
	@PutMapping("courses/updateCourse/{id}")
	public Course updateCourse(@RequestBody Course course) {
		LOGGER.info("Entry: CourseController - updateCourse");
		Course courseDto = courseService.updateCourse(course);
		LOGGER.info("Exit: CourseController - updateCourse");
		return courseDto;
		
	}
	
	@DeleteMapping("/courses/{id}")
	public String deleteCourse(@PathVariable("id") long id) {
		courseService.deleteCourse(id);
		System.out.println("Successfully Deleted Course with id : " +id);
		return "Successfully Deleted Course";
	}

}
