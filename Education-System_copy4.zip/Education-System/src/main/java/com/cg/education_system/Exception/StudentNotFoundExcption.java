package com.cg.education_system.Exception;


import lombok.AllArgsConstructor;

@AllArgsConstructor

public class StudentNotFoundExcption extends RuntimeException {
	
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	private static final long serialVersionUID = -9024299823525086362L;
	private String message;

}
