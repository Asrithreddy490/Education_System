package com.cg.education_system.ServiceImpl;

import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.education_system.Service.PaymentService;
import com.cg.education_system.entity.Payment;
import com.cg.education_system.entity.Student;
import com.cg.education_system.repository.PaymentRepository;
import com.cg.education_system.repository.StudentRepository;

@Service
public class PaymentServiceImpl implements PaymentService{
	Log LOGGER = LogFactory.getFactory().getLog(PaymentService.class);
	@Autowired
	PaymentRepository paymentRepository;
	
	@Autowired
	StudentRepository studentRepository;

	@Override
	public Payment savePayment(Payment payment) 
	{
		
		return paymentRepository.save(payment);
	}

	@Override
	public List<Payment> getAllPayments() {
		
		return paymentRepository.findAll();
	}

	@Override
	public Payment getPaymentById(long id) 
	{
//		Optional<Payment> paymentopt = paymentRepository.findById(id);
	
		return paymentRepository.findById(id).orElse(null);
		
	}

	@Override
	public String deletePayment(long id) {
		paymentRepository.deleteById(id);
		return "Payment Deleted od id:"+id;
		
	}

	@Override
	public Payment updatePayment(Payment payment) 
	{
		Payment existingPayment = paymentRepository.findById(payment.getId()).orElse(null);
		existingPayment.setAmountPaid(payment.getAmountPaid());
		existingPayment.setDescription(payment.getDescription());
		existingPayment.setPaymentDate(payment.getPaymentDate());
		
		return paymentRepository.save(existingPayment);
	}

	@Override
	public List<Payment> getPaymentByStudentId(long studentId) {
		
		return paymentRepository.findByStudent_id(studentId);
	}





}
