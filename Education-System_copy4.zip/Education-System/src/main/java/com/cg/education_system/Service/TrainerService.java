package com.cg.education_system.Service;

import java.util.List;
import com.cg.education_system.entity.Trainer;

public interface TrainerService {
	
	List<Trainer> getAllTrainers();
	Trainer getTrainer(long id);
	Trainer saveTrainer(Trainer trainer);
	Trainer updateTrainer(Trainer trainer);
	void deleteTrainer(long id);
}
