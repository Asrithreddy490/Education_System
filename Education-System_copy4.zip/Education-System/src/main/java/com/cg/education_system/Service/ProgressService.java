package com.cg.education_system.Service;

import java.util.List;

import com.cg.education_system.entity.Payment;
import com.cg.education_system.entity.Progress;

public interface ProgressService {
	
	List<Progress> getAllProgress();
	Progress getProgress(long id);
	Progress saveProgress(Progress progress);
	Progress updateProgress(Progress progress);
	void deleteProgress(long id);

}
