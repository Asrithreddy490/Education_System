package com.cg.education_system.Service;

import java.util.List;

import com.cg.education_system.entity.Course;
import com.cg.education_system.entity.Payment;

public interface CourseService {
	
	List<Course> getAllCourses();
	Course getCourse(long id);
	Course saveCourse(Course course);
	Course updateCourse(Course course);
	void deleteCourse(long id);

}
