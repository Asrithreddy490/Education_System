package com.cg.education_system.ServiceImpl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.cg.education_system.Service.TrainerSchuduleService;

import com.cg.education_system.entity.TrainingSchudle;
import com.cg.education_system.repository.TrainingSchuduleRepository;



@Service

public class TrainerSchuduleServiceImpl implements TrainerSchuduleService{
	
	@Autowired
	TrainingSchuduleRepository trainingSchuduleRepo;

	@Override
	public TrainingSchudle getTrainingSchudle(long id) {
		Optional<TrainingSchudle> Id=  trainingSchuduleRepo.findById(id);
		TrainingSchudle schedule = Id.get();
		return schedule;
	}

	@Override
	public TrainingSchudle saveTrainingSchudle(TrainingSchudle trainingSchudle) {
		
		return trainingSchuduleRepo.save(trainingSchudle);
	}

	@Override
	public TrainingSchudle updateTrainingSchudle(TrainingSchudle trainingSchudle) {
		return trainingSchuduleRepo.save(trainingSchudle);
	}

	@Override
	public void deleteTrainingSchudle(long id) {
		trainingSchuduleRepo.deleteById(id);
		
	}

	@Override
	public List<TrainingSchudle> getAllTrainingSchedule() {
		// TODO Auto-generated method stub
		return trainingSchuduleRepo.findAll();
	}

	
	
	
}
