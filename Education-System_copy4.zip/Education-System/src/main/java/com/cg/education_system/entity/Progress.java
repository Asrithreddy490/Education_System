package com.cg.education_system.entity;

//import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@NoArgsConstructor
@Table(name="student_progress")
public class Progress {
	
	
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name ="progress_id")
	private long id;

	@Column(name = "scored_marks", nullable = false)
	private int scoredMarks;
	
	@Column(name ="comment")
	private String comments;
	
	@OneToOne
	@JoinColumn(name ="student_id",insertable=false,updatable=false)
	private Student student;
	
	@Column(name="student_id")
	private long studentId;
	
	
	
	

}