package com.cg.education_system.Service;

import java.util.List;

import com.cg.education_system.entity.Student;



public interface StudentService {
	
	List<Student> getAllStudents();
	Student getStudent(long id);
	Student saveStudent(Student student);
	Student updateStudent(Student student);


}
