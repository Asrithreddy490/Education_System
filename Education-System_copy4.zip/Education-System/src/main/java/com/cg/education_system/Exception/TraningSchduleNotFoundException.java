package com.cg.education_system.Exception;

import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
public class TraningSchduleNotFoundException extends RuntimeException{

	/**
	 * 
	 */
	private static final long serialVersionUID = -7101519891308136031L;
	
	private String msg;

	public String getMsg() {
		return msg;
	}

	public void setMsg(String msg) {
		this.msg = msg;
	}

}
