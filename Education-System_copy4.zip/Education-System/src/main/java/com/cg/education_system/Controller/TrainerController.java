package com.cg.education_system.Controller;

import java.util.List;

import javax.validation.Valid;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.education_system.Service.TrainerService;
import com.cg.education_system.entity.Trainer;

@CrossOrigin("*")
@RestController
@RequestMapping("/es")
public class TrainerController {
	Log LOGGER = LogFactory.getFactory().getLog(TrainerController.class);
	@Autowired
	TrainerService trainerService;
	
	@GetMapping("/trainers")
	public List<Trainer> getAllTrainers(){
		
		LOGGER.info("Entry: TrainerController - getAllTrainers");
		
		List<Trainer> trainer = trainerService.getAllTrainers();
		
		LOGGER.info("Exit: TrainerController - getAllTrainers");
		return trainer;
		
	}
	
	@GetMapping("/trainers/{id}")
	public Trainer getTrainer(@PathVariable("id") long id) {
		
		LOGGER.info("Entry: TrainerController - getTrainer");
		
		Trainer trainerDto = trainerService.getTrainer(id);
		
		LOGGER.info("Exit: TrainerController - getTrainer");
		return trainerDto;
	}
	
	@Validated
	@PostMapping("/trainers")
	public Trainer saveTrainer(@RequestBody @Valid Trainer trainer) {
		
		LOGGER.info("Entry: TrainerController - saveTrainer");
		
		Trainer trainerDto = trainerService.saveTrainer(trainer);
		
		LOGGER.info("Exit: TrainerController - saveTrainer");
		return trainerDto;
	}
	
	@PutMapping("trainers/updateTrainer/{id}")
	public Trainer updateTrainer(@RequestBody Trainer trainer) {
		
		LOGGER.info("Entry: TrainerController - updateTrainer");
		
		Trainer trainerDto = trainerService.updateTrainer(trainer);
		
		LOGGER.info("Exit: TrainerController - updateTrainer");
		
		return trainerDto;
	   
	}
	
	@DeleteMapping("/trainers/{id}")
	public String deleteTrainer(@PathVariable("id") Long Id) {
		
		trainerService.deleteTrainer(Id);
		
		System.out.println("succesfully deleted trainer with id : " +Id);
		
		return "Successfully Deleted Trainer";
	}

}
