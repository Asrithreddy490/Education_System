package com.cg.education_system.Service;

import java.util.List;

import com.cg.education_system.entity.TrainingSchudle;

public interface TrainerSchuduleService {
	
	TrainingSchudle getTrainingSchudle(long id);
	TrainingSchudle saveTrainingSchudle(TrainingSchudle trainingSchudle);
	TrainingSchudle updateTrainingSchudle(TrainingSchudle trainingSchudle);
	void deleteTrainingSchudle(long id);
	List<TrainingSchudle> getAllTrainingSchedule();

}
