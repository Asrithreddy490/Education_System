package com.cg.education_system.entity;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotBlank;

import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@NoArgsConstructor
@Table(name="user_payment")
public class Payment{
	
	
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name ="payment_id")
	private long id;
	
//	@ManyToOne
//	private Student student;
	
	@NotBlank(message = "Amount paid must not be empty")
	@Column(name ="amount_paid")
	private String amountPaid;
	
	@NotBlank(message = "Date must not be empty")
	@Column(name ="payment_date")
	private String paymentDate;
	
	@NotBlank(message = "Description must not be empty")
	@Column(name ="description")
	private String description;
	
//	@OneToOne(cascade = CascadeType.MERGE)
//	@JoinColumn(name = "student_id")
//	private Student student;
	
	@ManyToOne
	@JoinColumn(name="student_id",insertable=false,updatable=false)
	private Student student;
	
	@Column(name="student_id")
	private long student_id;
	
	@ManyToOne
	@JoinColumn(name="course_id",insertable=false,updatable=false)
	private Course course;
	
	@Column(name="course_id")
	private long courseId;

}
