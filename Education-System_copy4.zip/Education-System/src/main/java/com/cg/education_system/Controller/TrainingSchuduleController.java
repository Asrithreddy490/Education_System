package com.cg.education_system.Controller;

import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.education_system.Service.TrainerSchuduleService;
import com.cg.education_system.entity.Payment;
import com.cg.education_system.entity.TrainingSchudle;

@RestController
@RequestMapping("/es/education")
@CrossOrigin("*")
public class TrainingSchuduleController {
	Log LOGGER = LogFactory.getFactory().getLog(TrainingSchuduleController.class);
	@Autowired
	TrainerSchuduleService trainerSchuduleService;
	
	@GetMapping("/trainings")
	public List<TrainingSchudle> getAllTrainingSchedule(){
		LOGGER.info("PaymentController::getAllPayments::Entered");
		List<TrainingSchudle> trainingSchudle = trainerSchuduleService.getAllTrainingSchedule();
		LOGGER.info("PaymentController::getAllPayments::Exits");
		return trainingSchudle;
		
	}
	
	
	@GetMapping("/trainings/{id}")
	public TrainingSchudle getTrainingSchudle(@PathVariable("id") Long id) {
		LOGGER.info("Entry: TrainingSchuduleController - getTrainingSchudle");
		TrainingSchudle trainingSchudleDto = trainerSchuduleService.getTrainingSchudle(id);
		LOGGER.info("Exit: TrainingSchuduleController - getTrainingSchudle");
		return trainingSchudleDto;
		
	}
	@PostMapping("/trainings")
	public TrainingSchudle saveTrainingSchudle(@RequestBody TrainingSchudle trainingSchudle) {
		LOGGER.info("Entry: TrainingSchuduleController - saveTrainingSchudle");
		TrainingSchudle trainingSchudleDto = trainerSchuduleService.saveTrainingSchudle(trainingSchudle);
		LOGGER.info("Exit: TrainingSchuduleController - saveTrainingSchudle");
		return trainingSchudleDto;
		
	}
	@PutMapping("/trainings/updateTraining/{id}")
	public TrainingSchudle updateTrainingSchudle(@RequestBody TrainingSchudle trainingSchudle) {
		LOGGER.info("Entry: TrainingSchuduleController - updateTrainingSchudle");
		TrainingSchudle trainingSchudleDto = trainerSchuduleService.updateTrainingSchudle(trainingSchudle);
		LOGGER.info("Exit: TrainingSchuduleController - updateTrainingSchudle");
		return trainingSchudleDto;
		
	}
	
	@DeleteMapping("/trainings/{id}")
	public String deleteTrainingSchudle(@PathVariable("id") Long Id) {
		trainerSchuduleService.deleteTrainingSchudle(Id);
		System.out.println("Successfully Deleted Training Schedule with id: " +  Id);
		return "Successfully Deleted Training Schedule";
		
	}

}
