package com.cg.education_system.ServiceImpl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.education_system.Service.ProgressService;
import com.cg.education_system.entity.Progress;
import com.cg.education_system.repository.ProgressRepository;

@Service
public class ProgressServiceImpl implements ProgressService{
	
	@Autowired
	
	ProgressRepository progressRepo;

	@Override
	public Progress getProgress(long id) {
		Optional<Progress> Id=  progressRepo.findById(id);
		Progress progress = Id.get();
		return progress;
	}

	@Override
	public Progress saveProgress(Progress progress) {
		// TODO Auto-generated method stub
		return progressRepo.save(progress);
	}

	@Override
	public Progress updateProgress(Progress progress) {
		// TODO Auto-generated method stub
		return progressRepo.save(progress);
	}

	@Override
	public void deleteProgress(long id) {
		
		progressRepo.deleteById(id);
	}

	@Override
	public List<Progress> getAllProgress() {
		// TODO Auto-generated method stub
		return progressRepo.findAll();
	}

	

}
