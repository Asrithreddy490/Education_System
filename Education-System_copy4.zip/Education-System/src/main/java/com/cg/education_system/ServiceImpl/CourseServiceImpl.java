package com.cg.education_system.ServiceImpl;

import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.education_system.Service.CourseService;
import com.cg.education_system.entity.Course;

import com.cg.education_system.repository.CourseRepository;

@Service
public class CourseServiceImpl implements CourseService{
	
	@Autowired
	CourseRepository courseRepo;


	@Override
	public Course getCourse(long id) {
		Optional<Course> Id=  courseRepo.findById(id);
		Course trainer = Id.get();
		return trainer;
	}


	@Override
	public Course saveCourse(Course course) {
		
		return courseRepo.save(course);
	}


	@Override
	public Course updateCourse(Course course) {
		
		return courseRepo.save(course);
	}


	@Override
	public void deleteCourse(long id) {
		courseRepo.deleteById(id);
		
	}


	@Override
	public List<Course> getAllCourses() {
		// TODO Auto-generated method stub
		return courseRepo.findAll();
	}

	
}
