package com.cg.education_system.ServiceImpl;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.education_system.Service.TrainerService;
import com.cg.education_system.entity.Trainer;
import com.cg.education_system.repository.TrainerRepository;

@Service
public class TrainerServiceImpl implements TrainerService {
	
	
	@Autowired
	TrainerRepository trainerRepo;

	@Override
	public List<Trainer> getAllTrainers() {
		// TODO Auto-generated method stub
		return trainerRepo.findAll();
	}

	@Override
	public Trainer getTrainer(long id) {
		Optional<Trainer> Id=  trainerRepo.findById(id);
		Trainer student = Id.get();
		return student;
	}

	@Override
	public Trainer saveTrainer(Trainer trainer) {
		
		return trainerRepo.save(trainer);
	}

	@Override
	public Trainer updateTrainer(Trainer trainer) {
		
		return trainerRepo.save(trainer);
	}

	@Override
	public void deleteTrainer(long id) {
		
		trainerRepo.deleteById(id);
		
	}

	

}
