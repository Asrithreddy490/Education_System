package com.cg.education_system.entity;


import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@AllArgsConstructor
@NoArgsConstructor
@Data
public class TrainingSchudle{
	
	
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name ="student_schedule")
	private long id;
	
	
	@Column(name ="start_date")
	private String startDate;
	
	@Column(name ="end_date")
	private String endDate;
	
	@Column(name ="timings")
	private String timings;
	
	//@JsonManagedReference
	@OneToOne(cascade = CascadeType.MERGE)
	@JoinColumn(name = "course_id",insertable=false,updatable=false)
	private Course course;
	
	@Column(name = "course_id")
	private long courseId;
	
	
	//@JsonManagedReference
	
	@OneToOne(cascade = CascadeType.MERGE)
	@JoinColumn(name = "trainer_id",insertable=false,updatable=false)
	private Trainer trainer;
	
	@Column(name="trainer_id")
	private long trainerId;
	
	
//	@OneToOne
//	@JoinColumn(name = "course_id",insertable=false,updatable=false)
//	private Course course;
//	

	
	
	
//	@JsonIgnore
//	@OneToMany
//	@JoinColumn(name="schedule_id")
//    private List<Student> students;

	

}