package com.cg.education_system.Service;

import java.util.List;

import com.cg.education_system.entity.Payment;

public interface PaymentService {
//	
//	PaymentDto getAllPayment(long studentid);
	List<Payment> getAllPayments();
//	Payment getPayment(long id,long studentid);
	Payment savePayment(Payment payment);
	Payment getPaymentById(long id);
	Payment updatePayment(Payment payment);
	String deletePayment(long id);
	List<Payment> getPaymentByStudentId(long studentId);

	
	

}
