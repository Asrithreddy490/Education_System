package com.cg.education_system.Controller;

import java.util.List;

import javax.validation.Valid;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.education_system.Service.PaymentService;
import com.cg.education_system.entity.Payment;

@RestController
@RequestMapping("/es")
@CrossOrigin("*")
public class PaymentController {
	Log LOGGER = LogFactory.getFactory().getLog(PaymentController.class);
	@Autowired
	PaymentService paymentService;
	
	@GetMapping("/payment/{id}")
	public Payment getPaymentById(@PathVariable("id") long id) {
		LOGGER.info("paymentController::getPayment::Entered");
		Payment payment = paymentService.getPaymentById(id);
		LOGGER.info("paymentController::getPayment::exiter");
		return payment;
		
	}
	
	
	@GetMapping("/payments")
	public List<Payment> getAllPayments(){
		LOGGER.info("PaymentController::getAllPayments::Entered");
		List<Payment> payment = paymentService.getAllPayments();
		LOGGER.info("PaymentController::getAllPayments::Exits");
		return payment;
		
	}
	

//	@GetMapping("/getpayment/{studentid}/{id}")
//	public PaymentDto getPayment(@PathVariable("id") long id,@PathVariable("studentid") long studentid) {
//		LOGGER.info("paymentController::getPayment::Entered");
//		PaymentDto paaymentDto = paymentService.getPayment(id,studentid);
//		LOGGER.info("paymentController::getPayment::exiter");
//		return paaymentDto;
//		
//	}
	@Validated
	@PostMapping("/payment")
	public Payment savePayment(@RequestBody @Valid Payment payment) {
		LOGGER.info("paymentController::savePayment::Entered");
		Payment payments = paymentService.savePayment(payment);
		LOGGER.info("paymentController::savePayment::exited");
		System.out.println("Successfully added payment "+ payment);
		return payments;
		
	}
	
	@Validated
	@PutMapping("/payment")
	public Payment updatePayment(@RequestBody @Valid Payment payment) {
		LOGGER.info("paymentController::updatePayment::Entered");
		Payment paayment = paymentService.updatePayment(payment);
		LOGGER.info("paymentController::updatePayment::exited");
		return paayment;
	}
	
	@DeleteMapping("/payment/{id}")
	public String deletePayment(@PathVariable("id") Long id) {
		paymentService.deletePayment(id);
		System.out.println("Successfully deleted payment with id :" + id);
		return "Successfully Deleted ";
	}
	
	@GetMapping("/payment/student/{studentId}")
	public List<Payment> getPaymentByStudentId(@PathVariable("studentId") long studentId) {
		List<Payment> payment = paymentService.getPaymentByStudentId(studentId);
		return payment;
	}
	


}
