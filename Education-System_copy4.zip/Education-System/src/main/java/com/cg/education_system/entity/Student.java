package com.cg.education_system.entity;


import java.io.Serializable;
import java.util.List;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "student_info")
public class Student{
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "roll_id")
	private long id;

	
	@NotBlank(message = "first name must not be null or empty")
	@Column(name = "first_name")
	private String firstName;
	
	@NotBlank(message = "last name must not be null or empty")
	@Column(name = "last_name")
	private String lastName;
	
	@Column(name = "mobile_number")
	private long mobile;
	
	@Email(message = "email must be in web-format abc@xyz.com")
	@Column(name = "email_address")
	private String email;
	
	@Column(name = "address")
	private String address;
	
	@OneToOne(cascade = CascadeType.MERGE)
	@JoinColumn(name = "student_progress")
	private Progress studentProgress;
	
//	
//	@OneToOne(cascade = CascadeType.MERGE)
//	@JoinColumn(name = "student_payment")

	@JsonIgnore
	@OneToMany
	@JoinColumn(name="student_id")
    private List<Payment> payments;
	
	@JsonIgnore
	@OneToOne(cascade = CascadeType.MERGE)
	@JoinColumn(name = "student_schedule")
	private TrainingSchudle schudle;
	
//	@ManyToOne
//	@JoinColumn(name="schedule_id",insertable=false,updatable=false)
//	private TrainingSchudle schedule;
//	
//	@Column(name="schedule_id")
//	private long schedule_id;
	
//	@NotBlank(message = "first name must not be null or empty")
	@Column(name = "password")
	private String password;
	
	
	
	

}