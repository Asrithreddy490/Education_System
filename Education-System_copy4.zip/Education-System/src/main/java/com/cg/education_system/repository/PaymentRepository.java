package com.cg.education_system.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.cg.education_system.entity.Payment;

@Repository
public interface PaymentRepository extends JpaRepository<Payment, Long>{

	List<Payment> findByStudent_id(long studentId);

	
}
