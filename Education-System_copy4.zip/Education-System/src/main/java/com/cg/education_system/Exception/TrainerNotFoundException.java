package com.cg.education_system.Exception;

import lombok.AllArgsConstructor;


@AllArgsConstructor
public class TrainerNotFoundException extends RuntimeException{

	public String getMsg() {
		return msg;
	}

	public void setMsg(String msg) {
		this.msg = msg;
	}

	/**
	 * 
	 */
	private static final long serialVersionUID = -1854387337900510981L;
	
	private String msg;
}
