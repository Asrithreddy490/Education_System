package com.cg.education_system.controller;

import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.cg.education_system.Controller.CourseController;
import com.cg.education_system.Service.CourseService;
import com.cg.education_system.entity.Course;

@ExtendWith(MockitoExtension.class)
public class CourseControllerTest {
	@InjectMocks
	CourseController courseController;
	
	@Mock
	CourseService courseService;
	
	@Test
	void getCourseTest() {
		long id = 1;
		Course course = createCourseDtoMockData();
		when(courseService.getCourse(id)).thenReturn(course);
		Course courseInfo = courseController.getCourse(id);
		assert(course.getId() == courseInfo.getId());
	}
	
	
	@Test
	void updateCourseTest() {
		//long id = 1;
		Course course = createCourseDtoMockData();
		when(courseService.updateCourse(course)).thenReturn(course);
		Course courseInfo = courseController.updateCourse(course);
		assert(course.getId() == courseInfo.getId());
	}
	
	
	
	@Test
	void saveCourseTest() {
		//long id = 1;
		Course course = createCourseDtoMockData();
		when(courseService.saveCourse(course)).thenReturn(course);
		Course courseInfo = courseController.saveCourse(course);
		assert(course.getId() == courseInfo.getId());
	}
	
	@Test
	void deleteCourseTest() {
		long id = 1;
		String msg = "Successfully Deleted Course";
		doNothing().when(courseService).deleteCourse(id);
		String message = courseController.deleteCourse(id);
		assert(message.equals(msg));
	}
	
	
	private Course createCourseDtoMockData(){
		Course course = new Course();
		course.setId(1);
		course.setCourse("java");
		return course;
	}

}
