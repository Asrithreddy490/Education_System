//package com.cg.education_system.service;
//
//import static org.mockito.Mockito.verify;
//import static org.mockito.Mockito.when;
//
//import java.util.ArrayList;
//import java.util.List;
//
//import org.junit.jupiter.api.BeforeEach;
//import org.junit.jupiter.api.Order;
//import org.junit.jupiter.api.Test;
//import org.junit.jupiter.api.extension.ExtendWith;
//import org.mockito.InjectMocks;
//import org.mockito.Mock;
//import org.mockito.junit.jupiter.MockitoExtension;
//
//
//import com.cg.education_system.Service.TrainerService;
//import com.cg.education_system.ServiceImpl.TrainerServiceImpl;
//import com.cg.education_system.entity.Trainer;
//import com.cg.education_system.repository.TrainerRepository;
//
//@ExtendWith(MockitoExtension.class)
//public class TrainerServiceTest {
//	
//    @InjectMocks
//	private TrainerService trainerService = new TrainerServiceImpl();
//	
//    @Mock 
//	private TrainerRepository trainerRepo;
//	
//	@BeforeEach
//	void setMockOutput() {
//		this.trainerService = new TrainerServiceImpl();
//	}
//
//
//	
//	@Test
//	@Order(1)
//	void saveTrainerTest() {
//		Trainer tr = new Trainer();
//		tr.setId(1);
//		tr.setFirstName("bhagi");
//		tr.setLastName("kotipalli");
//		tr.setEmail("bhagi@gmail.com");
//		tr.setMobile(676899768);
//		tr.setCourse(null);
//		
//		verify(trainerRepo).save(tr);
//		
//	}
//
//	@Test
//	@Order(2)
//	void updateTrainerTest() {
//		Trainer tr = new Trainer();
//		tr.setId(1);
//		tr.setFirstName("bhagi");
//		tr.setLastName("kotipalli");
//		tr.setEmail("bhagi@gmail.com");
//		tr.setMobile(676899768);
//		tr.setCourse(null);
//		
//		verify(trainerRepo).save(tr);
//		
//	}
//	
//	@Test
//	@Order(3)
//	void getTrainerTest() {
//		trainerService.getTrainer(1);
//		verify(trainerRepo).findById(null);
//	
//	}
//	
//	@Test
//	@Order(4)
//	void deleteTrainerTest() {
//		trainerService.deleteTrainer(1);
//		verify(trainerRepo).deleteById(null);
//	}
//	
//	
//	
//}