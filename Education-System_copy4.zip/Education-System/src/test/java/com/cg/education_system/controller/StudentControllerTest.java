package com.cg.education_system.controller;

import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.cg.education_system.Controller.StudentController;
import com.cg.education_system.Service.StudentService;
import com.cg.education_system.entity.Student;

@ExtendWith(MockitoExtension.class)

public class StudentControllerTest {
	
	@InjectMocks
	StudentController studentController;
	
	@Mock
	StudentService studentService;
	
	
	@Test
	void getAllStudentsTest() {
		
		List<Student> students = createStudentsDtoMockData();		
		when(studentService.getAllStudents()).thenReturn(students);
		
		List<Student> studentList = studentController.getAllStudents();
		
		assert(students.size() == studentList.size());
		
	}
	
	
	@Test
	void getStudentTest() {
		
		long id = 1;
		Student student = createStudentDtoMockData();		
		when(studentService.getStudent(id)).thenReturn(student);
		
		Student studentInfo = studentController.getStudent(id);
		
		assert(student.getId() == studentInfo.getId());
		
	}
	
	@Test
	
	void saveStudentTest() {
		Student student = createStudentDtoMockData();
		when(studentService.saveStudent(student)).thenReturn(student);
		Student studentInfo = studentController.saveStudent(student);
		assert(student.getId() == studentInfo.getId());
	}
	
	@Test
	void updateStudentTest() {
	
		Student student = createStudentDtoMockData();	
	
		when(studentService.updateStudent(student)).thenReturn(student);
		
		Student studentInfo = studentController.updateStudent(student);
		
		assert(student.getId() == studentInfo.getId());
		
	}
	
	
	private List<Student> createStudentsDtoMockData(){
		List<Student> students = new ArrayList<>();
		Student student = new Student();
		student.setId(1);
		student.setFirstName("bhagi");
		student.setLastName("kotipalli");
		student.setAddress(null);
		student.setMobile(678684587);
//		student.setRollId(1);
		student.setEmail("bhagi@gmail.com");
//		student.setPaymentId(null);
//		student.setProgressId(null);
		student.setSchudle(null);
		students.add(student);
		return students;
		
	}
	
	

	private Student createStudentDtoMockData() {
		Student student = new Student();
		student.setId(1);
		student.setFirstName("bhargavi");
		student.setLastName("koti");
		student.setAddress(null);
		student.setMobile(678684587);
//		student.setRollId(1);
		student.setEmail("bhagi@gmail.com");
//		student.setPaymentId(null);
//		student.setProgressId(null);
		student.setSchudle(null);
		return student;
	}

}
