package com.cg.education_system.controller;

import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.cg.education_system.Controller.PaymentController;
import com.cg.education_system.Service.PaymentService;
import com.cg.education_system.entity.Payment;

@ExtendWith(MockitoExtension.class)
public class PaymentControllerTest {
	
	@InjectMocks
	PaymentController paymentController;
	
	@Mock
	PaymentService paymentService;
	
	@Test
	void getPaymentTest() {
		long id = 1;
		Payment payment = createPaymentDtoMockData();
		when(paymentService.getPaymentById(id)).thenReturn(payment);
		Payment paymentInfo = paymentController.getPaymentById(id);
		assert(payment.getId() == paymentInfo.getId());
	}
	
	@Test
	void savePaymentTest() {
		//long id = 1;
		Payment payment = createPaymentDtoMockData();
		when(paymentService.savePayment(payment)).thenReturn(payment);
		Payment paymentInfo = paymentController.savePayment(payment);
		assert(payment.getId() == paymentInfo.getId());
	}
	
	
	@Test
	void updatePaymentTest() {
		//long id = 1;
		Payment payment = createPaymentDtoMockData();
		when(paymentService.updatePayment(payment)).thenReturn(payment);
		Payment paymentInfo = paymentController.updatePayment(payment);
		assert(payment.getId() == paymentInfo.getId());
	}
	
	
	@Test
	void deletePaymentTest() {
	
		long id = 1;
		String msg = "Successfully Deleted Payment Details";
		doNothing().when(paymentService).deletePayment(id);
		String message = paymentController.deletePayment(id);
		assert(message.equals(msg));
	
	}
	
	private Payment createPaymentDtoMockData(){
		Payment payment = new Payment();
		payment.setId(1);
		payment.setAmountPaid("500");
		payment.setDescription("exam fee");
		payment.setPaymentDate("11-03-2021");
		return payment;
		
	}
	
	

}
