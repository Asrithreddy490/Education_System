package com.cg.education_system.controller;

import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.cg.education_system.Controller.ProgressController;
import com.cg.education_system.Service.ProgressService;
import com.cg.education_system.entity.Progress;

@ExtendWith(MockitoExtension.class)
public class ProgressControllerTest {
	
	@InjectMocks
	ProgressController progressController;
	
	@Mock
	ProgressService progressSerivce;
	
	@Test
	void getProgressTest() {
		long id = 1;
		Progress progress = createProgressDtoMockData();
		when(progressSerivce.getProgress(id)).thenReturn(progress);
		Progress progressInfo = progressController.getProgress(id);
		assert(progress.getId() == progressInfo.getId());
	}
	
	@Test
	void saveProgressTest() {
		//long id = 1;
		Progress progress = createProgressDtoMockData();
		when(progressSerivce.saveProgress(progress)).thenReturn(progress);
		Progress progressInfo = progressController.saveProgress(progress);
		assert(progress.getId() == progressInfo.getId());
	}
	
	@Test
	void updateProgressTest() {
		//long id = 1;
		Progress progress = createProgressDtoMockData();
		when(progressSerivce.updateProgress(progress)).thenReturn(progress);
		Progress progressInfo = progressController.updateProgress(progress);
		assert(progress.getId() == progressInfo.getId());
	}
	
	@Test
	void deleteProgressTest() {
		long id = 1;
		String msg = "Successfully Deleted Progress Details";
		doNothing().when(progressSerivce).deleteProgress(id);
		String message = progressController.deleteProgress(id);
		assert(message.equals(msg));
	}
	
	private Progress createProgressDtoMockData(){
		Progress progress =new Progress();
		progress.setId(1);
		progress.setComments("Average");
		progress.setScoredMarks(55);
//		progress.setStudent(null);
		return progress;
		
	}

}
