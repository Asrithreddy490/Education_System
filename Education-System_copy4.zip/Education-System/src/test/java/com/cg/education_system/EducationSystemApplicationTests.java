package com.cg.education_system;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EducationSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
