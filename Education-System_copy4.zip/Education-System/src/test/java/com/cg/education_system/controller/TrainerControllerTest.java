package com.cg.education_system.controller;

import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.cg.education_system.Controller.TrainerController;
import com.cg.education_system.Service.TrainerService;
import com.cg.education_system.entity.Trainer;

@ExtendWith(MockitoExtension.class)
public class TrainerControllerTest {
	
	@InjectMocks
	TrainerController trainerController;
	
	@Mock
	TrainerService trainerService;
	
	
	@Test
	void getTrainerTest() {
		long id = 1;
		Trainer trainer = createTrainerDtoMockData();
		when(trainerService.getTrainer(id)).thenReturn(trainer);
		Trainer trainerInfo = trainerController.getTrainer(id);
		assert(trainer.getId() == trainerInfo.getId());
	}
	
	
	@Test
	void saveTrainerTest() {
		
		Trainer trainer = createTrainerDtoMockData();
		when(trainerService.saveTrainer(trainer)).thenReturn(trainer);
		Trainer studentInfo = trainerController.saveTrainer(trainer);
		assert(trainer.getId() == studentInfo.getId());
	}
	
	
	@Test
	void updateTrainerTest() {
		
		Trainer trainer = createTrainerDtoMockData();
		when(trainerService.updateTrainer(trainer)).thenReturn(trainer);
		Trainer studentInfo = trainerController.updateTrainer(trainer);
		assert(trainer.getId() == studentInfo.getId());
	}
	
	
	@Test
	void deleteTrainerTest() {
		long id = 1;
		String msg = "Successfully Deleted Trainer";
		doNothing().when(trainerService).deleteTrainer(id);
		String message = trainerController.deleteTrainer(id);
		assert(message.equals(msg));
	}
	
	
	private Trainer createTrainerDtoMockData(){
		Trainer trainer = new Trainer();
		trainer.setId(1);
		trainer.setFirstName("alisha");
		trainer.setLastName("shaik");
		trainer.setEmail("alisha@cg.com");
		trainer.setMobile(95687389);
		trainer.setCourse(null);
		return trainer;
	}
	

}
