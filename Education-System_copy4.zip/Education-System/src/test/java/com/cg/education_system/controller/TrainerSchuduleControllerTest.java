package com.cg.education_system.controller;

import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.cg.education_system.Controller.TrainingSchuduleController;
import com.cg.education_system.Service.TrainerSchuduleService;
import com.cg.education_system.entity.TrainingSchudle;

@ExtendWith(MockitoExtension.class)
public class TrainerSchuduleControllerTest {
	
	@InjectMocks
	TrainingSchuduleController trainingSchuduleController;
	
	@Mock
	TrainerSchuduleService trainerSchuduleService;
	
	
	@Test
	void getTrainingSchudleTest() {
		long id = 1;
		TrainingSchudle trainerSchudle = createTrainingDtoMockData();
		when(trainerSchuduleService.getTrainingSchudle(id)).thenReturn(trainerSchudle);
		TrainingSchudle trainingInfo = trainingSchuduleController.getTrainingSchudle(id);
		assert(trainerSchudle.getId() == trainingInfo.getId());
	}
	
	@Test
	void saveTrainingSchudleTest() {
		//long id = 1;
		TrainingSchudle trainerSchudle = createTrainingDtoMockData();
		when(trainerSchuduleService.saveTrainingSchudle(trainerSchudle)).thenReturn(trainerSchudle);
		TrainingSchudle trainingInfo = trainingSchuduleController.saveTrainingSchudle(trainerSchudle);
		assert(trainerSchudle.getId() == trainingInfo.getId());
	}
	
	@Test
	void updateTrainingSchudleTest() {
		//long id = 1;
		TrainingSchudle trainerSchudle = createTrainingDtoMockData();
		when(trainerSchuduleService.updateTrainingSchudle(trainerSchudle)).thenReturn(trainerSchudle);
		TrainingSchudle trainingInfo = trainingSchuduleController.updateTrainingSchudle(trainerSchudle);
		assert(trainerSchudle.getId() == trainingInfo.getId());
	}
	
	@Test
	void deleteTrainingSchudleTest() {
		long id = 1;
		String msg = "Successfully Deleted Training Schedule";
		doNothing().when(trainerSchuduleService).deleteTrainingSchudle(id);
		String message = trainingSchuduleController.deleteTrainingSchudle(id);
		assert(message.equals(msg));
	}
	
	
	
	private TrainingSchudle createTrainingDtoMockData(){
		TrainingSchudle trainingSchudle = new TrainingSchudle();
		trainingSchudle.setId(1);
		trainingSchudle.setCourse(null);
		trainingSchudle.setTimings("2hours");
		trainingSchudle.setStartDate("2/2/2022");
		trainingSchudle.setEndDate("3/3/2033");
		trainingSchudle.setTrainer(null);
		return trainingSchudle;
		
	}
	

}
