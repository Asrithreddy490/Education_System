//package com.cg.education_system.service;
//
//import static org.mockito.Mockito.verify;
//import static org.mockito.Mockito.when;
//
//import java.util.ArrayList;
//import java.util.List;
//
//import org.junit.jupiter.api.BeforeEach;
//import org.junit.jupiter.api.Order;
//import org.junit.jupiter.api.Test;
//import org.junit.jupiter.api.extension.ExtendWith;
//import org.mockito.InjectMocks;
//import org.mockito.Mock;
//import org.mockito.junit.jupiter.MockitoExtension;
//
//import com.cg.education_system.Service.StudentService;
//import com.cg.education_system.ServiceImpl.StudentServiceImpl;
//import com.cg.education_system.dto.StudentDto;
//import com.cg.education_system.entity.Student;
//import com.cg.education_system.repository.StudentRepository;
//
//
//@ExtendWith(MockitoExtension.class)
//public class StudentServiceTest {
//	
//    @InjectMocks
//	private StudentService studentService;
//	
//    @Mock 
//	private StudentRepository studentRepo;
//	
////	@BeforeEach
////	void setMockOutput() {
////		this.studentService = new StudentServiceImpl();
////	}
//
//	@Test
//	void getAllStudentsTest() {
//		List<Student> students = createStudentsEntityMockData();
//		when(studentRepo.findAll()).thenReturn(students);
//		List<StudentDto> studentList = studentService.getAllStudents();
//		assert(students.size() == studentList.size());
//
//	}
//	
//	
//	@Test
//	void getStudent() {
//		
//		studentService.getStudent(1);
//		verify(studentRepo).getById(null);
//		
//	}
//
//	private List<Student> createStudentsEntityMockData() {
//		// TODO Auto-generated method stub
//		List<Student> students = new ArrayList<>();
//		Student student = new Student();
//		student.setId(1);
//		student.setEmail("bhagi@cg.com");
//		student.setFirstName("bhagi");
//		student.setLastName("koti");
//		student.setMobile("87968676");
//		student.setAddress(null);
//		student.setRollId(1);
//		student.setPaymentId(null);
//		student.setProgressId(null);
//		student.setSchudle(null);
//		students.add(student);
//		
//		return students;
//		
//	}
//	
//	private Student StudentMockData() {
//		Student studentss = new Student();
//		studentss.setId(1);
//		studentss.setFirstName("bhagi");
//		studentss.setLastName("ram");
//		studentss.setAddress(null);
//		studentss.setMobile("74935799");
//		studentss.setRollId(1);
//		studentss.setEmail("bhagi@gm.com");
//		studentss.setPaymentId(null);
//		studentss.setProgressId(null);
//		studentss.setSchudle(null);
//		return studentss;
//	}
//	
//	@Test
//	void saveStudentTest() {
//		Student stu = new Student();
//		stu.setId(1);
//		stu.setFirstName("bhagi");
//		stu.setLastName("kotipalli");
//		stu.setEmail("bhagi@gmail.com");
//		stu.setMobile("676899768");
//		stu.setAddress(null);
//		stu.setRollId(1);
//		stu.setPaymentId(null);
//		stu.setProgressId(null);
//		stu.setSchudle(null);
//		
//		verify(studentRepo).save(stu);
//		
//	}
//	
//	@Test
//	void updateStudentTest() {
//		Student stu = new Student();
//		stu.setId(1);
//		stu.setFirstName("bhagi");
//		stu.setLastName("kotipalli");
//		stu.setEmail("bhagi@gmail.com");
//		stu.setMobile("676899768");
//		stu.setAddress(null);
//		stu.setRollId(1);
//		stu.setPaymentId(null);
//		stu.setProgressId(null);
//		stu.setSchudle(null);
//		
//		verify(studentRepo).save(stu);
//		
//	}
//	
//	
//	
//}
